# Hardware One — Training Commands

## Step 1: Verify environment

```bash
python3 --version
```

```bash
python3 -c "import torch; print('PyTorch:', torch.__version__); print('CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none')"
```

```bash
python3 -c "import transformers, tokenizers, accelerate; print('deps ok')"
```

---

## Step 2: Install dependencies (if not done)

```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

```bash
pip install transformers datasets tokenizers accelerate
```

---

## Step 3: Train the narrow2 model (recommended — deeper, better topic discrimination)

Uses all four Hardware One training files. The `narrow2` preset uses dim=128 (20 layers) instead of
dim=256 (8 layers), giving the network more depth to correctly associate answers with their topics.
Use this if the `narrow` model produces the right vocabulary but the wrong topic context.

```bash
python3 train_tiny_model_gpu.py --preset narrow2 \
  --text hardwareone_qa.txt hardwareone_qa_expanded.txt hardwareone_overview.txt hardwareone_qa_v2.txt \
  --epochs 200 \
  --batch-size 8 \
  --lr 3e-4 \
  --out ./out_narrow2
```

> You should see output within seconds: GPU info, "Loaded N text paragraphs...", "Training BPE tokenizer...".
> If nothing appears after 30 seconds, kill and try the CPU script (Step 5).

---

## Step 4: Train the narrow model (shallower, faster inference)

Uses only the Hardware One training data. Optimized for domain Q&A with richer per-head attention (head_size=32).
Use this if you need faster inference on the device or want to compare against narrow2.

```bash
python3 train_tiny_model_gpu.py --preset narrow \
  --text hardwareone_qa.txt hardwareone_qa_expanded.txt hardwareone_overview.txt hardwareone_qa_v2.txt \
  --epochs 200 \
  --batch-size 8 \
  --lr 3e-4 \
  --out ./out_narrow
```

---

## Step 5: Train the stretch2 model (more layers, general purpose)

```bash
python3 train_tiny_model_gpu.py --preset stretch2 \
  --text hardwareone_qa.txt hardwareone_qa_expanded.txt hardwareone_overview.txt hardwareone_qa_v2.txt \
  --epochs 10 \
  --out ./out_stretch2
```

---

## Step 6 (old Step 5): CPU fallback (if GPU script hangs)

```bash
python3 train_tiny_model.py --preset narrow2 \
  --text hardwareone_qa.txt hardwareone_qa_expanded.txt hardwareone_overview.txt hardwareone_qa_v2.txt \
  --epochs 200 \
  --out ./out_narrow2
```

---

## Step 7: Estimate parameter count without training

```bash
python3 train_tiny_model_gpu.py --preset narrow2 --estimate-only
```

```bash
python3 train_tiny_model_gpu.py --preset narrow --estimate-only
```

```bash
python3 train_tiny_model_gpu.py --preset stretch2 --estimate-only
```

---

## Troubleshooting

**Hangs immediately / no output at all:**
```bash
python3 -c "import torch; print(torch.zeros(10))"
```
If this hangs, torch install is broken. Reinstall deps.

**Hangs after "Training BPE tokenizer...":**
Normal — training tokenizer on your text files. Wait 30 seconds.

**Hangs after "torch.compile...":**
Normal on first run — compiles CUDA kernels. Wait up to 2 minutes.

**CUDA out of memory:**
Add `--batch-size 16` or `--batch-size 8` to the command.

**"No module named X":**
```bash
pip install transformers datasets tokenizers accelerate
```

**Check what's happening (run with verbose output):**
```bash
python3 -u train_tiny_model_gpu.py --preset narrow2 \
  --text hardwareone_qa.txt hardwareone_qa_expanded.txt hardwareone_overview.txt hardwareone_qa_v2.txt \
  --epochs 200 --batch-size 8 --lr 3e-4 \
  --out ./out_narrow2 2>&1 | tee training.log
```

---

## After training

Copy the output folder back to the Mac converter machine:

```bash
scp -r ./out_narrow2 user@macbook:/Users/morgan/esp/llm-converter/
```

Then open `index.html` in the converter, drag in the output folder, select INT8, download `model.bin`, copy to SD card.

---

## Preset comparison

| Preset  | Vocab | dim | Layers | n_head | head_size | Wts   | +KV@64 | Total  | Notes                              |
|---------|-------|-----|--------|--------|-----------|-------|--------|--------|------------------------------------|
| narrow2 | 4K    | 128 | 20     | 4      | 32        | ~4.7  | ~1.3   | ~6.9MB | ★ Deep domain Q&A, rich attention  |
| narrow  | 4K    | 256 | 8      | 8      | 32        | ~5.1  | ~1.0   | ~6.1MB | Wide attention, fast inference     |
| stretch2| 8K    | 128 | 20     | 8      | 16        | ~5.4  | ~1.3   | ~6.7MB | General, wider FFN                 |
| stretch | 8K    | 128 | 18     | 8      | 16        | ~4.4  | ~1.1   | ~5.5MB | General depth                      |

`narrow2` uses ~6.9 MB total PSRAM at ctx=64 (~1 MB headroom). **Load with ctx=64 or 96 max —
ctx=128 will exceed 8 MB and fail to load.** 2.5× more layers than `narrow`, head_size=32,
wider FFN (n_inner=640). **Use narrow2 for Hardware One domain Q&A.**
